﻿// === FILE: functions/[[path]].js ===

import CONFIG from "../config.js";

import {
    getSeries,
    getSeriesCredits,
    getSeason,
    getEpisode,
    getEpisodeCredits
} from "./tmdb.js";

import {
    renderHomepage,
    renderSeasonPage,
    renderEpisodePage,
    buildEpisodeImage
} from "./renderer.js";

import {
    renderTMDBError,
    renderConfigurationError,
    renderNotFound,
    htmlResponse
} from "./fallback.js";

const CACHE_TTL = "public,max-age=300,s-maxage=3600";
const ADS_CACHE_TTL = "public,max-age=300";

async function getCached(request) {
    try {
        return await caches.default.match(request);
    } catch {
        return null;
    }
}

async function putCache(request, response) {
    try {
        await caches.default.put(request, response.clone());
    } catch {
        // cache failure must never crash
    }
}

async function serveAd(context, filename) {
    try {
        const response = await context.env.ASSETS.fetch(
            new Request(new URL(`/ads/${filename}`, context.request.url))
        );

        if (!response || !response.ok) {
            return new Response("", {
                status: 200,
                headers: {
                    "content-type": "text/html; charset=utf-8",
                    "cache-control": ADS_CACHE_TTL
                }
            });
        }

        return new Response(await response.text(), {
            status: 200,
            headers: {
                "content-type": "text/html; charset=utf-8",
                "cache-control": ADS_CACHE_TTL
            }
        });
    } catch {
        return new Response("", {
            status: 200,
            headers: {
                "content-type": "text/html; charset=utf-8",
                "cache-control": ADS_CACHE_TTL
            }
        });
    }
}

function createUpcomingEpisode(series, seasonNumber, episodeNumber) {
    return {
        id: 0,
        name: `Episode ${episodeNumber}`,
        overview: "",
        episode_number: episodeNumber,
        season_number: seasonNumber,
        air_date: null,
        still_path: null,
        vote_average: 0
    };
}

function currentUrl(request) {
    return request.url;
}

export async function onRequest(context) {
    const { request, env } = context;

    if (!env?.TMDB_TOKEN) {
        return htmlResponse(
            renderConfigurationError(
                "TMDB_TOKEN ไม่ถูกกำหนดใน Cloudflare Pages Environment Variables"
            ),
            500,
            "no-cache"
        );
    }

    const url = new URL(request.url);
    const pathname = url.pathname.replace(/\/+$/, "") || "/";

    // ==================================================
// STATIC ASSETS
// ==================================================

if (
    pathname.startsWith("/assets/") ||
    pathname.startsWith("/ads/") ||
    pathname === "/favicon.png" ||
    pathname === "/tv.mp4"
) {
    return context.next();
}
    
    // ==================================================
    // ADS ROUTER
    // ==================================================

    if (pathname === "/cair-320x50.html") {
        return serveAd(context, "320x50.html");
    }

    if (pathname === "/cair-300x250.html") {
        return serveAd(context, "300x250.html");
    }

    if (pathname === "/cair-160x300.html") {
        return serveAd(context, "160x300.html");
    }

    const cached = await getCached(request);

    if (cached) {
        return cached;
    }

    try {

        // ==================================================
        // HOMEPAGE
        // ==================================================

        if (pathname === "/") {

            const [series, credits] = await Promise.all([
                getSeries(env),
                getSeriesCredits(env)
            ]);

            const html = renderHomepage({
                series,
                credits,
                url: currentUrl(request)
            });

            const response = htmlResponse(
                html,
                200,
                CACHE_TTL
            );

            await putCache(request, response);

            return response;
        }

        // ==================================================
        // ROUTE PARSER
        // ==================================================

        const route = pathname.replace("/", "");

        const episodeMatch = route.match(
            /^(\d+)-(\d+)-(\d+)$/
        );

        const seasonMatch = route.match(
            /^(\d+)-(\d+)$/
        );

        // ==================================================
        // EPISODE PAGE
        // ==================================================

        if (episodeMatch) {

            const seriesId = Number(episodeMatch[1]);
            const seasonNumber = Number(episodeMatch[2]);
            const episodeNumber = Number(episodeMatch[3]);

            if (seriesId !== CONFIG.SERIES_ID) {
                return htmlResponse(
                    renderNotFound(),
                    404,
                    "no-cache"
                );
            }

            const [
                series,
                aggregateCredits,
                season
            ] = await Promise.all([
                getSeries(env),
                getSeriesCredits(env),
                getSeason(env, seasonNumber)
            ]);

            let episode;
            let episodeCredits = { cast: [] };

            try {
                episode = await getEpisode(
                    env,
                    seasonNumber,
                    episodeNumber
                );

                try {
                    episodeCredits = await getEpisodeCredits(
                        env,
                        seasonNumber,
                        episodeNumber
                    );
                } catch {
                    episodeCredits = { cast: [] };
                }

            } catch {

                episode = createUpcomingEpisode(
                    series,
                    seasonNumber,
                    episodeNumber
                );

                episode.image = buildEpisodeImage({
                    episodeStill: null,
                    seasonPoster: season?.poster_path,
                    seriesBackdrop: series?.backdrop_path,
                    seriesPoster: series?.poster_path
                });
            }

            const html = renderEpisodePage({
                series,
                season,
                episode,
                credits: episodeCredits,
                aggregateCredits,
                url: currentUrl(request)
            });

            const response = htmlResponse(
                html,
                200,
                CACHE_TTL
            );

            await putCache(request, response);

            return response;
        }

        // ==================================================
        // SEASON PAGE
        // ==================================================

        if (seasonMatch) {

            const seriesId = Number(seasonMatch[1]);
            const seasonNumber = Number(seasonMatch[2]);

            if (seriesId !== CONFIG.SERIES_ID) {
                return htmlResponse(
                    renderNotFound(),
                    404,
                    "no-cache"
                );
            }

            const [series, season] = await Promise.all([
                getSeries(env),
                getSeason(env, seasonNumber)
            ]);

            const html = renderSeasonPage({
                series,
                season,
                url: currentUrl(request)
            });

            const response = htmlResponse(
                html,
                200,
                CACHE_TTL
            );

            await putCache(request, response);

            return response;
        }

        return htmlResponse(
            renderNotFound(),
            404,
            "no-cache"
        );

    } catch {

        return htmlResponse(
            renderTMDBError(),
            500,
            "no-cache"
        );
    }
}
