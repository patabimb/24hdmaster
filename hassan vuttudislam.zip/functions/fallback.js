﻿// === FILE: functions/fallback.js ===

import CONFIG from "../config.js";

function renderDocument(title, message) {
    return `<!DOCTYPE html>
<html lang="${CONFIG.LANGUAGE}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${title}</title>
<link rel="icon" href="/favicon.png">
<style>
:root{
    color-scheme:dark;
}
*{
    box-sizing:border-box;
}
body{
    margin:0;
    min-height:100vh;
    display:flex;
    align-items:center;
    justify-content:center;
    background:#050505;
    color:#ffffff;
    font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
    padding:24px;
}
.card{
    width:100%;
    max-width:680px;
    background:#111111;
    border:1px solid rgba(255,255,255,.08);
    border-radius:24px;
    padding:32px;
}
h1{
    margin:0 0 16px;
    font-size:28px;
}
p{
    margin:0;
    line-height:1.7;
    color:rgba(255,255,255,.78);
}
</style>
</head>
<body>
<div class="card">
<h1>${title}</h1>
<p>${message}</p>
</div>
</body>
</html>`;
}

export function renderTMDBError() {
    return renderDocument(
        "ไม่สามารถโหลดข้อมูลซีรีส์ได้",
        "ขณะนี้ระบบไม่สามารถเชื่อมต่อข้อมูลจาก TMDB ได้ กรุณาลองใหม่อีกครั้งในภายหลัง"
    );
}

export function renderConfigurationError(message = "") {
    return renderDocument(
        "การตั้งค่าระบบไม่สมบูรณ์",
        message || "กรุณาตรวจสอบการตั้งค่า TMDB_TOKEN ใน Cloudflare Pages Environment Variables"
    );
}

export function renderNotFound() {
    return renderDocument(
        "ไม่พบหน้าที่ต้องการ",
        "หน้าที่คุณกำลังค้นหาไม่มีอยู่ในระบบ"
    );
}

export function htmlResponse(html, status = 200, cacheControl = "no-cache") {
    return new Response(html, {
        status,
        headers: {
            "content-type": "text/html; charset=utf-8",
            "cache-control": cacheControl
        }
    });
}