﻿// === FILE: functions/tmdb.js ===

import CONFIG from "../config.js";

const API_BASE = "https://api.themoviedb.org/3";

function buildHeaders(env) {
    if (!env?.TMDB_TOKEN) {
        throw new Error("TMDB_TOKEN environment variable is missing.");
    }

    return {
        Authorization: `Bearer ${env.TMDB_TOKEN}`,
        Accept: "application/json"
    };
}

async function tmdbFetch(env, endpoint) {
    const response = await fetch(`${API_BASE}${endpoint}`, {
        headers: buildHeaders(env)
    });

    if (!response.ok) {
        throw new Error(`TMDB request failed: ${response.status}`);
    }

    return response.json();
}

export async function getSeries(env) {
    return tmdbFetch(
        env,
        `/tv/${CONFIG.SERIES_ID}?language=${CONFIG.LANGUAGE}`
    );
}

export async function getSeriesCredits(env) {
    return tmdbFetch(
        env,
        `/tv/${CONFIG.SERIES_ID}/aggregate_credits?language=${CONFIG.LANGUAGE}`
    );
}

export async function getSeason(env, seasonNumber) {
    return tmdbFetch(
        env,
        `/tv/${CONFIG.SERIES_ID}/season/${seasonNumber}?language=${CONFIG.LANGUAGE}`
    );
}

export async function getEpisode(env, seasonNumber, episodeNumber) {
    return tmdbFetch(
        env,
        `/tv/${CONFIG.SERIES_ID}/season/${seasonNumber}/episode/${episodeNumber}?language=${CONFIG.LANGUAGE}`
    );
}

export async function getEpisodeCredits(env, seasonNumber, episodeNumber) {
    return tmdbFetch(
        env,
        `/tv/${CONFIG.SERIES_ID}/season/${seasonNumber}/episode/${episodeNumber}/credits?language=${CONFIG.LANGUAGE}`
    );
}

export function getImageUrl(path, size = "w780") {
    if (!path) return null;

    return `https://image.tmdb.org/t/p/${size}${path}`;
}

export function getBackdropUrl(path) {
    return getImageUrl(path, "w1280");
}

export function getPosterUrl(path) {
    return getImageUrl(path, "w780");
}

export function getProfileUrl(path) {
    return getImageUrl(path, "w185");
}

export function getStillUrl(path) {
    return getImageUrl(path, "w780");
}