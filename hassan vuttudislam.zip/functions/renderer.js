// === FILE: functions/renderer.js ===

import CONFIG from "../config.js";
import {
    getBackdropUrl,
    getPosterUrl,
    getProfileUrl,
    getStillUrl
} from "./tmdb.js";

function escapeHtml(value = "") {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#39;");
}

function imageFallback(...urls) {
    for (const url of urls) {
        if (url && String(url).trim()) {
            return url;
        }
    }

    return "/favicon.png";
}

export function buildEpisodeImage({
    episodeStill,
    seasonPoster,
    seriesBackdrop,
    seriesPoster
}) {
    return imageFallback(
        getStillUrl(episodeStill),
        getPosterUrl(seasonPoster),
        getBackdropUrl(seriesBackdrop),
        getPosterUrl(seriesPoster),
        "/favicon.png"
    );
}

export function renderHistats() {
    if (!CONFIG.HISTATS_ENABLED) {
        return "";
    }

    return `
<script type="text/javascript">
var _Hasync = _Hasync || [];
_Hasync.push(['Histats.start', '1,${CONFIG.HISTATS_ID},4,0,0,0,00010000']);
_Hasync.push(['Histats.fasi', '1']);
_Hasync.push(['Histats.track_hits', '']);
(function() {
    var hs = document.createElement('script');
    hs.type = 'text/javascript';
    hs.async = true;
    hs.src = '//s10.histats.com/js15_as.js';
    (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
})();
</script>
<noscript>
<a href="/" target="_blank">
<img src="//sstatic1.histats.com/0.gif?${CONFIG.HISTATS_ID}&101" alt="">
</a>
</noscript>
`;
}

function renderHead({
    title,
    description,
    image,
    canonical
}) {
    return `
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">

<title>${escapeHtml(title)}</title>

<meta name="description" content="${escapeHtml(description)}">
<meta name="robots" content="index,follow">
<meta name="theme-color" content="#000000">

<link rel="icon" href="/favicon.png">
<link rel="canonical" href="${escapeHtml(canonical)}">

<meta property="og:type" content="website">
<meta property="og:title" content="${escapeHtml(title)}">
<meta property="og:description" content="${escapeHtml(description)}">
<meta property="og:image" content="${escapeHtml(image)}">

<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="${escapeHtml(title)}">
<meta name="twitter:description" content="${escapeHtml(description)}">
<meta name="twitter:image" content="${escapeHtml(image)}">

<link rel="stylesheet" href="/assets/css/style.css">
`;
}

function layout({
    title,
    description,
    image,
    canonical,
    body
}) {
    return `<!DOCTYPE html>
<html
lang="${CONFIG.LANGUAGE}"
data-redirect-domain="${escapeHtml(CONFIG.REDIRECT_DOMAIN)}"
data-redirect-seconds="${escapeHtml(CONFIG.AUTO_REDIRECT_SECONDS)}">
<head>
${renderHead({
    title,
    description,
    image,
    canonical
})}
</head>
<body>

<div class="main-navigation" style="text-align: center; margin: 15px auto;">
    <a href="/" style="display: inline-block; padding: 10px 25px; background-color: #e50914; color: #ffffff; text-decoration: none; border-radius: 5px; font-weight: bold; font-family: sans-serif; transition: background 0.2s;">
        หน้าแรก / Home
    </a>
</div>

<div data-ad-slot="/iklan-320x50.html" style="display: flex; justify-content: center; width: 100%; margin: 15px auto;">
    <script>
  atOptions = {
    'key' : '9cbca9fc3fab1a4816a56e2fcd9cedb9',
    'format' : 'iframe',
    'height' : 50,
    'width' : 320,
    'params' : {}
  };
</script>
<script src="https://buffcasualwhine.com/9cbca9fc3fab1a4816a56e2fcd9cedb9/invoke.js"></script>

<script>
  atOptions = {
    'key' : '9cbca9fc3fab1a4816a56e2fcd9cedb9',
    'format' : 'iframe',
    'height' : 50,
    'width' : 320,
    'params' : {}
  };
</script>
<script src="https://buffcasualwhine.com/9cbca9fc3fab1a4816a56e2fcd9cedb9/invoke.js"></script>

</div>

${body}

<script type="module" src="/assets/js/app.js"></script>

${renderHistats()}

</body>
</html>`;
}

export function renderHomepage({
    series,
    credits,
    url
}) {
    const backdrop = imageFallback(
        getBackdropUrl(series.backdrop_path),
        getPosterUrl(series.poster_path),
        "/favicon.png"
    );

    const poster = imageFallback(
        getPosterUrl(series.poster_path),
        getBackdropUrl(series.backdrop_path),
        "/favicon.png"
    );

    const cast = (credits?.cast || []).slice(0, 12);

    const seasons = (series.seasons || [])
        .filter(item => item.season_number > 0);

    return layout({
        title: `${series.name} | ${CONFIG.SITE_NAME}`,
        description: series.overview || series.name,
        image: backdrop,
        canonical: url,
        body: `
<section class="hero" style="background-image:url('${backdrop}')">
<div class="hero-overlay"></div>

<div class="container hero-content">

<img
class="poster"
src="${poster}"
alt="${escapeHtml(series.name)}">

<div class="hero-info">

<h1>${escapeHtml(series.name)}</h1>

<p class="overview">
${escapeHtml(series.overview || "")}
</p>

<div class="meta-grid">

<div><strong>คะแนน</strong><span>${series.vote_average || "-"}</span></div>

<div><strong>สถานะ</strong><span>${escapeHtml(series.status || "-")}</span></div>

<div><strong>จำนวนซีซัน</strong><span>${series.number_of_seasons || 0}</span></div>

<div><strong>เครือข่าย</strong><span>${escapeHtml(series.networks?.[0]?.name || "-")}</span></div>

<div><strong>ผู้สร้าง</strong><span>${escapeHtml(series.created_by?.[0]?.name || "-")}</span></div>

<div><strong>สตูดิโอ</strong><span>${escapeHtml(series.production_companies?.[0]?.name || "-")}</span></div>

<div><strong>ประเภท</strong><span>${escapeHtml(
(series.genres || []).map(x => x.name).join(", ")
)}</span></div>

</div>

</div>

</div>
</section>

<section class="section">
<div class="container">

<section class="section">
<div class="container">

<h2>ซีซันทั้งหมด</h2>

<div class="season-grid">

${seasons.map(season => `
<a
class="season-card"
href="/${CONFIG.SERIES_ID}-${season.season_number}">

<img
loading="lazy"
src="${imageFallback(
getPosterUrl(season.poster_path),
poster
)}"
alt="${escapeHtml(season.name)}">

<h3>ซีซัน ${season.season_number}</h3>

</a>
`).join("")}

</div>

</div>
</section>

<section class="section">
<div class="container">

<div style="text-align: center; margin: 20px auto;">
    <script>
  atOptions = {
    'key' : '40ecfb714f1985e7398bb0e2a12dc5c3',
    'format' : 'iframe',
    'height' : 250,
    'width' : 300,
    'params' : {}
  };
</script>
<script src="https://buffcasualwhine.com/40ecfb714f1985e7398bb0e2a12dc5c3/invoke.js"></script>

<script>
  atOptions = {
    'key' : '40ecfb714f1985e7398bb0e2a12dc5c3',
    'format' : 'iframe',
    'height' : 250,
    'width' : 300,
    'params' : {}
  };
</script>
<script src="https://buffcasualwhine.com/40ecfb714f1985e7398bb0e2a12dc5c3/invoke.js"></script>

</div>

</div>
</section>

<h2>นักแสดงหลัก</h2>

<div class="cast-grid">

${cast.map(actor => `
<div class="cast-card">

<img
loading="lazy"
src="${imageFallback(
getProfileUrl(actor.profile_path),
"/favicon.png"
)}"
alt="${escapeHtml(actor.name)}">

<h3>${escapeHtml(actor.name)}</h3>

<p>${escapeHtml(actor.roles?.[0]?.character || "-")}</p>

</div>
`).join("")}

</div>

<div style="text-align: center; margin: 25px auto;">
    <script>
  atOptions = {
    'key' : 'b1459668f954a85fab060a214b597df2',
    'format' : 'iframe',
    'height' : 300,
    'width' : 160,
    'params' : {}
  };
</script>
<script src="https://buffcasualwhine.com/b1459668f954a85fab060a214b597df2/invoke.js"></script>

<script>
  atOptions = {
    'key' : 'b1459668f954a85fab060a214b597df2',
    'format' : 'iframe',
    'height' : 300,
    'width' : 160,
    'params' : {}
  };
</script>
<script src="https://buffcasualwhine.com/b1459668f954a85fab060a214b597df2/invoke.js"></script>

</div>

</div>
</section>
`
    });
}

export function renderSeasonPage({
    series,
    season,
    url
}) {
    const seasonPoster = imageFallback(
        getPosterUrl(season.poster_path),
        getPosterUrl(series.poster_path),
        getBackdropUrl(series.backdrop_path),
        "/favicon.png"
    );

    return layout({
        title: `${series.name} - ซีซัน ${season.season_number}`,
        description: season.overview || season.name,
        image: seasonPoster,
        canonical: url,
        body: `
<section class="page-header">
<div class="container">

<img
class="season-poster"
src="${seasonPoster}"
alt="${escapeHtml(season.name)}">

<h1>${escapeHtml(season.name)}</h1>

<p>${escapeHtml(season.overview || "")}</p>

<div class="season-count">
จำนวนตอน: ${season.episodes?.length || 0}
</div>

<div style="text-align: center; margin: 15px auto;">
    IKLAN 300X250 (PASANG 2)
</div>

</div>
</section>

<section class="section">
<div class="container">

<div class="episode-grid">

${(season.episodes || []).map(ep => `
<a
class="episode-card"
href="/${CONFIG.SERIES_ID}-${season.season_number}-${ep.episode_number}">

<img
loading="lazy"
src="${buildEpisodeImage({
episodeStill: ep.still_path,
seasonPoster: season.poster_path,
seriesBackdrop: series.backdrop_path,
seriesPoster: series.poster_path
})}"
alt="${escapeHtml(ep.name || "")}">

<div class="episode-content">
<h3>ตอน ${ep.episode_number}</h3>
<p>${escapeHtml(ep.name || `Episode ${ep.episode_number}`)}</p>
</div>

</a>
`).join("")}

</div>

<div style="text-align: center; margin: 25px auto;">
    IKLAN 160X300 (PASANG 2)
</div>

</div>
</section>
`
    });
}

export function renderEpisodePage({
    series,
    season,
    episode,
    credits,
    aggregateCredits,
    url
}) {
    const cast = (
        credits?.cast?.length
            ? credits.cast
            : aggregateCredits?.cast || []
    ).slice(0, 12);

    const image = buildEpisodeImage({
        episodeStill: episode?.still_path,
        seasonPoster: season?.poster_path,
        seriesBackdrop: series?.backdrop_path,
        seriesPoster: series?.poster_path
    });

    const episodeName =
        episode?.name ||
        `Episode ${episode?.episode_number || 0}`;

    return layout({
        title: `${series.name} - Season ${season.season_number} Episode ${episode.episode_number}`,
        description: episode.overview || series.overview || "",
        image,
        canonical: url,
        body: `
<section class="episode-page">

<div class="container">

<div class="episode-header">

<h1>${escapeHtml(series.name)}</h1>

<h2>
Season ${season.season_number}
Episode ${episode.episode_number}
</h2>

</div>

<div class="player-wrapper">

<video
id="tv-player"
controls
playsinline
preload="metadata"
poster="${image}">

<source
src="${CONFIG.PLAYER_SOURCE}"
type="video/mp4">

</video>

</div>

<div style="text-align: center; margin: 20px auto;">
    IKLAN 300X250 (PASANG 2)
</div>

${
episode.overview
? `
<section class="episode-overview">
<h3>เรื่องย่อ</h3>
<p>${escapeHtml(episode.overview)}</p>
</section>
`
: ""
}

<section class="cast-section">

<h3>นักแสดง</h3>

<div class="cast-grid">

${cast.map(actor => `
<div class="cast-card">

<img
loading="lazy"
src="${imageFallback(
getProfileUrl(actor.profile_path),
"/favicon.png"
)}"
alt="${escapeHtml(actor.name)}">

<h4>${escapeHtml(actor.name)}</h4>

<p>${escapeHtml(
actor.character ||
actor.roles?.[0]?.character ||
"-"
)}</p>

</div>
`).join("")}

</div>

</section>

<div style="text-align: center; margin: 25px auto;">
    IKLAN 160X300 (PASANG 2)
</div>

</div>

</section>
`
    });
}
