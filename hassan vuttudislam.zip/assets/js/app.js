﻿// === FILE: assets/js/app.js ===

const App = (() => {

    function getHtmlConfig() {
        const html = document.documentElement;

        return {
            redirectDomain:
                html.dataset.redirectDomain || "",

            redirectSeconds:
                Number(html.dataset.redirectSeconds || 0)
        };
    }

    function initLazyImages() {

        const images = document.querySelectorAll(
            'img[loading="lazy"]'
        );

        if (!("IntersectionObserver" in window)) {
            return;
        }

        const observer = new IntersectionObserver(
            entries => {

                entries.forEach(entry => {

                    if (!entry.isIntersecting) {
                        return;
                    }

                    const image = entry.target;

                    if (image.dataset.src) {
                        image.src = image.dataset.src;
                    }

                    observer.unobserve(image);
                });

            },
            {
                rootMargin: "200px"
            }
        );

        images.forEach(image => {
            observer.observe(image);
        });
    }

    function initAds() {

        const slots = document.querySelectorAll(
            "[data-ad-slot]"
        );

        if (!slots.length) {
            return;
        }

        slots.forEach(async slot => {

            const adFile = slot.dataset.adSlot;

            if (!adFile) {
                return;
            }

            try {

                const response = await fetch(adFile, {
                    credentials: "same-origin"
                });

                if (!response.ok) {
                    return;
                }

                slot.innerHTML = await response.text();

            } catch {
                // ad failure must never crash
            }

        });
    }

    function initRedirectTimer() {

        const player =
            document.getElementById("tv-player");

        if (!player) {
            return;
        }

        const {
            redirectDomain,
            redirectSeconds
        } = getHtmlConfig();

        if (!redirectDomain) {
            return;
        }

        if (redirectSeconds <= 0) {
            return;
        }

        let timerStarted = false;

        player.addEventListener(
            "play",
            () => {

                if (timerStarted) {
                    return;
                }

                timerStarted = true;

window.setTimeout(() => {
    try {

        window.location.href = redirectDomain;
    } catch {
        // ignore
    }
}, redirectSeconds * 1000);

            },
            {
                passive: true
            }
        );
    }

    function boot() {

        initLazyImages();

        initAds();

        initRedirectTimer();
    }

    if (
        document.readyState === "loading"
    ) {

        document.addEventListener(
            "DOMContentLoaded",
            boot,
            {
                once: true
            }
        );

    } else {

        boot();
    }

    return {
        boot
    };

})();

export default App;
